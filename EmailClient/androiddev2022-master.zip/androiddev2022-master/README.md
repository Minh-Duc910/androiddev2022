# USTH ICT 2022 Android Application Development

Students are expected to:

- Fork this repository to your github account
- Update student name and ID to this README file
- Push your commits regularly, with proper commit messages

# Student Info

- Name: Nguyễn Quốc Hùng
- ID: BI10-072
- Group ID: 14
